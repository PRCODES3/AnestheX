plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.anesthex"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anesthex"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.glance:glance-appwidget:1.1.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
