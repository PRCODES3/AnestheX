package com.anesthex.widget

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.security.SecureRandom

object SecureShare {
    fun encrypt(json: ByteArray, passphrase: String): Triple<ByteArray, ByteArray, ByteArray> {
        val salt = random(16)
        val key = deriveKey(passphrase, salt)
        val iv = random(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val cc = cipher.doFinal(json)
        return Triple(cc, iv, salt)
    }

    fun decrypt(ciphertext: ByteArray, iv: ByteArray, salt: ByteArray, passphrase: String): ByteArray {
        val key = deriveKey(passphrase, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun deriveKey(passphrase: String, salt: ByteArray): SecretKey {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, 100_000, 256)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }
    private fun random(n: Int): ByteArray = ByteArray(n).also { SecureRandom().nextBytes(it) }
    fun pack(ct: ByteArray, iv: ByteArray, salt: ByteArray): String {
        return listOf(ct, iv, salt).joinToString(".") { Base64.encodeToString(it, Base64.NO_WRAP) }
    }
    fun unpack(token: String): Triple<ByteArray, ByteArray, ByteArray> {
        val parts = token.split(".")
        return Triple(Base64.decode(parts[0], Base64.NO_WRAP), Base64.decode(parts[1], Base64.NO_WRAP), Base64.decode(parts[2], Base64.NO_WRAP))
    }
}
