package com.anesthex.widget.ui

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Toast.makeText(this, "Launch app host for AnestheX widgets", Toast.LENGTH_LONG).show()
        finish()
    }
}
