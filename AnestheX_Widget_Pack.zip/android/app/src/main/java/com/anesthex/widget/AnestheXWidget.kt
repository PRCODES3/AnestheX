package com.anesthex.widget

import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.FontWeight
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.action.actionRunCallback
import android.content.Context
import android.content.Intent
import android.graphics.Color
import com.anesthex.widget.ui.MainActivity

class AnestheXWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(Sizes.small, Sizes.medium))

    @Composable
    override fun Content() {
        val size = LocalSize.current
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
        ) {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalAlignment = Alignment.Vertical.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Row(modifier = GlanceModifier.fillMaxWidth(), horizontalAlignment = Alignment.Horizontal.SpaceBetween) {
                    Text(text = "ANESTHE·X", style = TextStyle(color = ColorProvider(Color.WHITE), fontWeight = FontWeight.Bold))
                    Spacer(modifier = GlanceModifier.defaultWeight())
                    Text(text = "⤴︎", style = TextStyle(color = ColorProvider(Color.WHITE)))
                }
                Spacer(8.dp)
                Text(text = "Next Case", style = TextStyle(color = ColorProvider(Color.LTGRAY)))
                Text(text = "00:45:00", style = TextStyle(color = ColorProvider(Color.WHITE), fontWeight = FontWeight.Bold))
                Spacer(8.dp)
                Row {
                    Text(text = "[Quick‑Calc]", style = TextStyle(color = ColorProvider(Color.BLACK)))
                    Spacer(8.dp)
                    Text(text = "[Checklist(3)]", style = TextStyle(color = ColorProvider(Color.BLACK)))
                }
            }
        }
    }
}

class AnestheXWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AnestheXWidget()
}
