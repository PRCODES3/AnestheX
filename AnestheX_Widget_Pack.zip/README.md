# AnestheX — OR‑Ready Widgets (iOS & Android)

**Bold, black‑and‑white, 3D‑accented widget pack for anesthesiologists.**  
This starter kit includes native widgets and secure file‑sharing stubs you can extend into a sellable app.

> ⚖️ **Important:** These tools are for informational/educational use only and **not** a medical device.  
> Do not use defaults for clinical dosing — make all calculators configurable to your local protocol.

## What’s inside
- **iOS (WidgetKit, SwiftUI)**: Next case timer, quick checklist chip, “EZ‑Share” launcher with end‑to‑end encryption (CryptoKit) stubs.
- **Android (Glance AppWidget, Kotlin)**: Matching layout and actions, AES‑GCM sharing stubs.
- **Branding**: Black/white wordmark + minimalist “Dr. Iso” mascot (SVG).
- **Docs**: Store listing copy, privacy policy template, license.

## High‑value concept (you can ship/sell)
- **Quick‑Calc**: Weight‑based calculators with *user‑defined* mg/kg factors and institutional presets. No fixed dosing shipped.
- **OR Checklist**: One‑tap, case‑type specific lists (airway/line/positioning) saved as JSON profiles.
- **Next Case Timer**: Pulls schedule from calendar URL (implement in app) and shows countdown.
- **EZ‑Share**: End‑to‑end encrypted share of checklists, case notes, and handoff PDFs via QR or link.
- **Character + 3D**: Monochrome 3D accents and “Dr. Iso” assistant in black/white.

## Quick start (iOS)
1. Open `ios/AnestheXWidget` as an Xcode project folder (Xcode 15+).
2. Add a host app target (or reuse your app) exposing URL scheme `anesthex://`.
3. Run on device. Add the **AnestheX** widget from your Home Screen.
4. Implement your real data sources in `AnestheXCore/Models.swift` and sharing in `SecureShare.swift`.

## Quick start (Android)
1. Open `android/` in Android Studio (Koala+). Use Kotlin + Glance (Compose).
2. Set applicationId in `build.gradle.kts` if you change package name.
3. Run on device, then long‑press Home Screen → Widgets → **AnestheX**.
4. Implement real schedule and secure sharing in `SecureShare.kt`.

## File sharing (E2EE) model
- Generate per‑share symmetric key (AES‑GCM 256).
- Derive share code (short passphrase) → PBKDF2 to wrap the key (or use platform secure enclave/keystore).
- Encrypt JSON payload (checklist/case summary) → Base64.
- Show QR or share link with ciphertext + salt + iv. Recipient enters code to decrypt on device.

## Store‑ready positioning
- **Audience:** Anesthesiologists/CRNAs/Residents.
- **Pitch:** “Your OR cockpit at a glance — checklists, configurable calcs, secure handoffs.”
- **Pricing:** $9.99–$19.99 one‑time, or $2.99/mo for cloud backup + team packs.

© 2025 AnestheX. MIT License; see `LICENSE`.
