import Foundation
import CryptoKit

// MARK: - Checklist model
struct ChecklistItem: Codable, Identifiable {
    var id: UUID = UUID()
    var title: String
    var checked: Bool = false
}

struct ChecklistProfile: Codable, Identifiable {
    var id: UUID = UUID()
    var name: String
    var items: [ChecklistItem]
}

// MARK: - Secure Share (AES-GCM stubs)
struct SecureShare {
    static func encrypt(json: Data, passphrase: String) throws -> (ct: Data, iv: Data, salt: Data) {
        let salt = randomData(count: 16)
        let key = try deriveKey(passphrase: passphrase, salt: salt)
        let iv = randomData(count: 12)
        let sealed = try AES.GCM.seal(json, using: key, nonce: AES.GCM.Nonce(data: iv))
        return (sealed.ciphertext + (sealed.tag), iv, salt)
    }
    static func decrypt(ct: Data, iv: Data, salt: Data, passphrase: String) throws -> Data {
        let key = try deriveKey(passphrase: passphrase, salt: salt)
        let nonce = try AES.GCM.Nonce(data: iv)
        // last 16 bytes are tag
        let tag = ct.suffix(16)
        let body = ct.prefix(ct.count - 16)
        let sealedBox = try AES.GCM.SealedBox(nonce: nonce, ciphertext: body, tag: tag)
        return try AES.GCM.open(sealedBox, using: key)
    }
    static func deriveKey(passphrase: String, salt: Data) throws -> SymmetricKey {
        let pw = Data(passphrase.utf8)
        // Simple PBKDF2 via CryptoKit is not exposed; in a production app,
        // use CommonCrypto or a vetted KDF. For the stub, we hash multiple rounds.
        var hash = SHA256.hash(data: pw + salt)
        for _ in 0..<4096 {
            hash = SHA256.hash(data: Data(hash) + pw + salt)
        }
        return SymmetricKey(data: Data(hash))
    }
    static func randomData(count: Int) -> Data { Data((0..<count).map { _ in UInt8.random(in: 0...255) }) }
}
