import WidgetKit
import SwiftUI
import Intents

struct CaseEntry: TimelineEntry {
    let date: Date
    let nextCaseTime: Date
    let checklistCount: Int
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> CaseEntry {
        CaseEntry(date: Date(), nextCaseTime: Date().addingTimeInterval(3600), checklistCount: 3)
    }
    func getSnapshot(in context: Context, completion: @escaping (CaseEntry) -> ()) {
        completion(placeholder(in: context))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<CaseEntry>) -> ()) {
        let entry = CaseEntry(date: Date(), nextCaseTime: Date().addingTimeInterval(3600), checklistCount: 3)
        let timeline = Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(300)))
        completion(timeline)
    }
}

struct AnestheXWidgetEntryView : View {
    var entry: Provider.Entry

    var body: some View {
        ZStack {
            Color.black
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image("wordmark") // supply in host app if desired
                        .resizable()
                        .scaledToFit()
                        .frame(height: 16)
                        .opacity(0.9)
                    Spacer()
                    Link(destination: URL(string: "anesthex://open?target=share")!) {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.white)
                    }
                }
                .padding(.bottom, 2)
                Text("Next Case")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.8))
                Text(entry.nextCaseTime, style: .timer)
                    .font(.title.bold())
                    .foregroundColor(.white)
                HStack {
                    Link("Quick‑Calc", destination: URL(string: "anesthex://open?target=calc")!)
                        .font(.footnote.weight(.medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.white)
                        .cornerRadius(8)
                    Link("Checklist (\(entry.checklistCount))", destination: URL(string: "anesthex://open?target=checklist")!)
                        .font(.footnote.weight(.medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.white)
                        .cornerRadius(8)
                    Spacer()
                    Image("mascot") // monochrome mascot
                        .resizable()
                        .scaledToFit()
                        .frame(height: 28)
                        .opacity(0.9)
                }
            }
            .padding()
        }
    }
}

struct AnestheXWidget: Widget {
    let kind: String = "AnestheXWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            AnestheXWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("AnestheX")
        .description("Your OR cockpit at a glance.")
        .supportedFamilies([.systemMedium, .systemLarge])
    }
}
