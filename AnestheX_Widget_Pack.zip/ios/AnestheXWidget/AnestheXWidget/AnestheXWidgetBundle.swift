import SwiftUI
import WidgetKit

@main
struct AnestheXWidgetBundle: WidgetBundle {
    var body: some Widget {
        AnestheXWidget()
    }
}
