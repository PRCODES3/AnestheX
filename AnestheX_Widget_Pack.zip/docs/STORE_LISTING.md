# Store Listing (Draft)

**Title:** AnestheX — OR Widgets & Secure Handoff  
**Subtitle:** Bold black‑and‑white anesthesiology widgets with encrypted sharing.

**Short description:**  
Your OR cockpit at a glance: configurable quick‑calcs, one‑tap checklists, next‑case timer, and encrypted handoffs.

**Long description:**  
AnestheX brings the essentials to your Home Screen. Launch configurable, protocol‑aligned calculators, tick through
case‑type checklists, and securely hand off notes via encrypted QR or link. Monochrome, 3D‑accented visuals keep it
clean and bold — perfect for low‑light theaters.

**Key features:**
- Configurable mg/kg calculators (you control factors/protocols)
- One‑tap checklists with profile presets (airway/line/position/meds)
- Next‑case timer (pull from your app’s schedule/calendar)
- Encrypted EZ‑Share (AES‑GCM) of checklists & notes
- Minimal black/white theme, 3D accents, “Dr. Iso” assistant

**Safety:** Informational only. Not a medical device.
