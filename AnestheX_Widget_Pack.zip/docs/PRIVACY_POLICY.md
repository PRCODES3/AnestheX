# Privacy Policy (Template)

AnestheX does not collect personal health information by default. Data remains on device unless you explicitly share.
EZ‑Share encrypts data client‑side with AES‑GCM; only recipients with your share code can decrypt. We do not operate
servers by default in this starter kit. Integrations you add may change this; document them accordingly.
